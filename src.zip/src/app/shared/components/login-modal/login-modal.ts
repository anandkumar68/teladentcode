export class LoginModal{
    type!: string;
    content!: string;
    allowUser!: String;
  }