import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctors-reviews',
  templateUrl: './doctors-reviews.component.html',
  styleUrls: ['./doctors-reviews.component.css']
})
export class DoctorsReviewsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
