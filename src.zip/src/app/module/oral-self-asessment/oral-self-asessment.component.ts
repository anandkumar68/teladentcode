import { Component, OnInit } from '@angular/core';



@Component({
  selector: 'app-oral-self-asessment',
  templateUrl: './oral-self-asessment.component.html',
  styleUrls: ['./oral-self-asessment.component.css']
})
export class OralSelfAsessmentComponent implements OnInit {
  

   step: any = 1;

  constructor() { }

  ngOnInit(): void {
  }
  

}

